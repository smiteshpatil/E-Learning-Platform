import React from "react";

const Revenue = () => {
  return <div>Revenue</div>;
};

export default Revenue;
