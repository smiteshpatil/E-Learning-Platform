package com.app.entities;

public enum Role {
	ROLE_ADMIN, ROLE_STUDENT, ROLE_INSTRUCTOR, ROLE_UNKNOWN
}
