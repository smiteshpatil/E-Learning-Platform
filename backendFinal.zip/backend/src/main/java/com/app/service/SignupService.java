package com.app.service;

import com.app.dto.Signup;

public interface SignupService {
	Signup registerNewUser(Signup request);
}
